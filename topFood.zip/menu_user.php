<div class="info-left">
    <h2 class="info-left--heading">Thông tin người dùng</h2>
    <ul class="info_left--list">
        <a href="./info_user.php" class="info-left--item info-active">
            <i class='bx bx-user'></i>Thông tin
        </a>

        <a href="./info_user_order.php" class="info-left--item order-active"><i class='bx bx-shopping-bag'></i>
            Đơn hàng
        </a>
        <a href="#" class="info-left--item">
            <i class='bx bx-heart'></i>
            Yêu thích
        </a>
        <a href="#" class="info-left--item"><i class='bx bx-cog'></i>
            Cài đặt
        </a>
        <a href="#" class="info-left--item"><i class='bx bx-bell'></i>
            Thông báo
        </a>
        <a href="#" class="info-left--item">
            <i class='bx bx-log-out-circle'></i>
            Thoát
        </a>
    </ul>
</div>