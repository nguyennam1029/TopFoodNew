# Flix Movie Website

    How To Create Responsive Movie Website Using HTML CSS And jQuery

# Preview



# Video

    https://youtu.be/4vgkZslEl1w

# Description

    We will make Responsive Movie Website Using HTML CSS And jQuery, Owl Carousel

# Resource

    Boxicons: https://boxicons.com/

    Google font: https://fonts.google.com/

    Owl Carousel: https://owlcarousel2.github.io/OwlCarousel2/docs/started-welcome.html
