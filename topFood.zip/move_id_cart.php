<?php
$id = $_GET['id'];
header('location:product_detail.php');
